def main() -> None:
	import run_all
	run_all.main(devmode = True)

if __name__ == '__main__':
	main()
